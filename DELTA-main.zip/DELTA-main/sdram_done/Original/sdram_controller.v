module sdram_controller (
    // Bus
    input in_HCLK,
    input in_HRESET,
    input in_HWRITE,
    input in_HSEL,
    input [31:0] in_HWDATA,
    input [31:0] in_HADDR,
    output reg out_HREADY,
    output reg [31:0] out_HRDATA,
    // SDRAM
    input [31:0] in_sdram_read_data,
    output reg out_CS,
    output reg out_write_en,
    output reg out_CAS,
    output reg out_RAS,
    output reg [1:0] out_bank_select,
    output reg [13:0] out_sdram_addr,
    output reg [31:0] out_sdram_write_data
);
    // Registers
    reg [31:0] hold_HWDATA;
    reg [31:0] hold_sdram_read_data;
    reg [3:0] state, next_state;
    localparam IDLE = 4'b0000,
               READ_ACT = 4'b0001,
               READ_NOP1 = 4'b0010,
               READ_CAS = 4'b0011,
               READ_NOP2 = 4'b0100,
               READ_NOP3 = 4'b0101,
               WRITE_ACT = 4'b0110,
               WRITE_NOP1 = 4'b0111,
               WRITE_CAS = 4'b1000,
               WRITE_NOP2 = 4'b1001,
               WRITE_NOP3 = 4'b1010;
    
    // State transition
    always @(posedge in_HRESET or posedge in_HCLK) begin
        if (in_HRESET) begin
            state <= IDLE;
            out_HREADY <= 1'b1;
            out_HRDATA <= 32'b0;
            hold_HWDATA <= 32'b0;
            hold_sdram_read_data <= 32'b0;
            out_CS <= 1'b1;
            out_RAS <= 1'b1;
            out_CAS <= 1'b1;
            out_write_en <= 1'b1;
            out_bank_select <= 2'b0;
            out_sdram_addr <= 14'b0;
            out_sdram_write_data <= 32'b0;
        end
        else begin
            state <= next_state;
        end
    end
    
    // FSM
    always @(*) begin
        case (state)
            IDLE: begin
                if (in_HSEL && in_HWRITE) begin
                    out_HREADY = 1'b0;
                    hold_sdram_read_data = in_sdram_read_data;
                    next_state = READ_ACT;
                end
                else if (in_HSEL && !in_HWRITE) begin
                    out_HREADY = 1'b0;
                    hold_HWDATA = in_HWDATA;
                    next_state = WRITE_ACT;
                end
                else begin
                    next_state = IDLE;
                end
            end
            READ_ACT: begin
                out_sdram_addr = in_HADDR[13:0];
                out_bank_select = in_HADDR[15:14];
                out_CS = 1'b0;
                out_RAS = 1'b0;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = READ_NOP1;
            end
            READ_NOP1: begin
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = READ_CAS;
            end
            READ_CAS: begin
                out_sdram_addr = {5'b0, in_HADDR[24:16]};
                out_bank_select = in_HADDR[15:14];
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b0;
                out_write_en = 1'b1;
                next_state = READ_NOP2;
            end
            READ_NOP2: begin
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = READ_NOP3;
            end
            READ_NOP3: begin
                out_HRDATA = hold_sdram_read_data;
                out_HREADY = 1'b1;
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = IDLE;
            end
            WRITE_ACT: begin
                out_sdram_addr = in_HADDR[13:0];
                out_bank_select = in_HADDR[15:14];
                out_CS = 1'b0;
                out_RAS = 1'b0;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = WRITE_NOP1;
            end
            WRITE_NOP1: begin
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = WRITE_CAS;
            end
            WRITE_CAS: begin
                out_sdram_addr = {5'b0, in_HADDR[24:16]};
                out_bank_select = in_HADDR[15:14];
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b0;
                out_write_en = 1'b0;
                out_sdram_write_data = hold_HWDATA;
                next_state = WRITE_NOP2;
            end
            WRITE_NOP2: begin
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = WRITE_NOP3;
            end
            WRITE_NOP3: begin
                out_CS = 1'b0;
                out_RAS = 1'b1;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = IDLE;
            end
            default: begin
                out_CS = 1'b1;
                out_RAS = 1'b1;
                out_CAS = 1'b1;
                out_write_en = 1'b1;
                next_state = IDLE;
            end
        endcase
    end
endmodule